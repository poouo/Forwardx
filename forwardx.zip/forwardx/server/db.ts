/**
 * SQLite 数据访问层（基于 better-sqlite3 + drizzle-orm/better-sqlite3）。
 *
 * 设计原则：
 * 1. 为了让上层（routers / agentRoutes）保持改动最小，所有导出函数仍然返回 Promise（async）。
 * 2. 时间字段统一为 unix epoch 秒（integer），代码层与 JS Date 互转。
 * 3. updatedAt 没有 onUpdate 触发器，由本文件的 update* 函数显式写入 new Date()。
 * 4. 数据库文件路径取自 SQLITE_PATH，默认 /data/forwardx.db；目录不存在自动创建。
 */

import { and, asc, desc, eq, gte, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/better-sqlite3";
import Database from "better-sqlite3";
import {
  InsertUser, users,
  hosts, InsertHost, Host,
  forwardRules, InsertForwardRule, ForwardRule,
  hostMetrics, InsertHostMetric,
  trafficStats, InsertTrafficStat,
  agentTokens, InsertAgentToken,
  forwardTests, InsertForwardTest,
} from "../drizzle/schema";
import crypto from "crypto";
import fs from "fs";
import path from "path";
import { ENV } from "./env";

let _db: ReturnType<typeof drizzle> | null = null;
let _sqlite: Database.Database | null = null;

function resolveDbPath(): string {
  const p = ENV.sqlitePath || "/data/forwardx.db";
  const dir = path.dirname(p);
  try { fs.mkdirSync(dir, { recursive: true }); } catch { /* ignore */ }
  return p;
}

export async function getDb() {
  if (_db) return _db;
  try {
    const dbPath = resolveDbPath();
    _sqlite = new Database(dbPath);
    _sqlite.pragma("journal_mode = WAL");
    _sqlite.pragma("synchronous = NORMAL");
    _sqlite.pragma("foreign_keys = ON");
    _db = drizzle(_sqlite);
    console.log(`[Database] SQLite opened at ${dbPath}`);
  } catch (error) {
    console.error("[Database] Failed to open SQLite:", error);
    _db = null;
  }
  return _db;
}

// ==================== Password Hashing ====================

function hashPassword(password: string): string {
  const salt = crypto.randomBytes(16).toString("hex");
  const hash = crypto.scryptSync(password, salt, 64).toString("hex");
  return `${salt}:${hash}`;
}

function verifyPassword(password: string, stored: string): boolean {
  const [salt, hash] = stored.split(":");
  if (!salt || !hash) return false;
  const testHash = crypto.scryptSync(password, salt, 64).toString("hex");
  return hash === testHash;
}

// ==================== Initialization ====================

export async function initDatabase() {
  const db = await getDb();
  if (!db || !_sqlite) {
    console.warn("[Database] Cannot initialize: SQLite not available");
    return;
  }
  try {
    _sqlite.exec(`
      CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT NOT NULL UNIQUE,
        password TEXT NOT NULL,
        name TEXT,
        email TEXT,
        role TEXT NOT NULL DEFAULT 'user',
        createdAt INTEGER NOT NULL DEFAULT (unixepoch()),
        updatedAt INTEGER NOT NULL DEFAULT (unixepoch()),
        lastSignedIn INTEGER NOT NULL DEFAULT (unixepoch())
      );

      CREATE TABLE IF NOT EXISTS hosts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        ip TEXT NOT NULL,
        port INTEGER DEFAULT 22,
        hostType TEXT NOT NULL DEFAULT 'slave',
        connectionType TEXT NOT NULL DEFAULT 'agent',
        sshUser TEXT,
        sshPassword TEXT,
        sshKeyContent TEXT,
        agentToken TEXT,
        osInfo TEXT,
        cpuInfo TEXT,
        memoryTotal INTEGER,
        networkInterface TEXT,
        isOnline INTEGER NOT NULL DEFAULT 0,
        lastHeartbeat INTEGER,
        userId INTEGER NOT NULL,
        createdAt INTEGER NOT NULL DEFAULT (unixepoch()),
        updatedAt INTEGER NOT NULL DEFAULT (unixepoch())
      );
      CREATE INDEX IF NOT EXISTS idx_hosts_user ON hosts(userId);
      CREATE INDEX IF NOT EXISTS idx_hosts_token ON hosts(agentToken);

      CREATE TABLE IF NOT EXISTS forward_rules (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        hostId INTEGER NOT NULL,
        name TEXT NOT NULL,
        forwardType TEXT NOT NULL DEFAULT 'iptables',
        protocol TEXT NOT NULL DEFAULT 'tcp',
        sourcePort INTEGER NOT NULL,
        targetIp TEXT NOT NULL,
        targetPort INTEGER NOT NULL,
        uploadLimit INTEGER NOT NULL DEFAULT 0,
        downloadLimit INTEGER NOT NULL DEFAULT 0,
        isEnabled INTEGER NOT NULL DEFAULT 1,
        isRunning INTEGER NOT NULL DEFAULT 0,
        userId INTEGER NOT NULL,
        createdAt INTEGER NOT NULL DEFAULT (unixepoch()),
        updatedAt INTEGER NOT NULL DEFAULT (unixepoch())
      );
      CREATE INDEX IF NOT EXISTS idx_rules_host ON forward_rules(hostId);
      CREATE INDEX IF NOT EXISTS idx_rules_user ON forward_rules(userId);

      CREATE TABLE IF NOT EXISTS host_metrics (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        hostId INTEGER NOT NULL,
        cpuUsage INTEGER,
        memoryUsage INTEGER,
        memoryUsed INTEGER,
        networkIn INTEGER,
        networkOut INTEGER,
        diskUsage INTEGER,
        uptime INTEGER,
        recordedAt INTEGER NOT NULL DEFAULT (unixepoch())
      );
      CREATE INDEX IF NOT EXISTS idx_host_metrics_host_time ON host_metrics(hostId, recordedAt DESC);

      CREATE TABLE IF NOT EXISTS traffic_stats (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        ruleId INTEGER NOT NULL,
        hostId INTEGER NOT NULL,
        bytesIn INTEGER NOT NULL DEFAULT 0,
        bytesOut INTEGER NOT NULL DEFAULT 0,
        connections INTEGER NOT NULL DEFAULT 0,
        recordedAt INTEGER NOT NULL DEFAULT (unixepoch())
      );
      CREATE INDEX IF NOT EXISTS idx_traffic_rule_time ON traffic_stats(ruleId, recordedAt DESC);
      CREATE INDEX IF NOT EXISTS idx_traffic_host_time ON traffic_stats(hostId, recordedAt DESC);

      CREATE TABLE IF NOT EXISTS agent_tokens (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        token TEXT NOT NULL UNIQUE,
        hostId INTEGER,
        description TEXT,
        isUsed INTEGER NOT NULL DEFAULT 0,
        userId INTEGER NOT NULL,
        createdAt INTEGER NOT NULL DEFAULT (unixepoch())
      );
      CREATE INDEX IF NOT EXISTS idx_agent_tokens_user ON agent_tokens(userId);

      CREATE TABLE IF NOT EXISTS forward_tests (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        ruleId INTEGER NOT NULL,
        hostId INTEGER NOT NULL,
        userId INTEGER NOT NULL,
        status TEXT NOT NULL DEFAULT 'pending',
        listenOk INTEGER NOT NULL DEFAULT 0,
        targetReachable INTEGER NOT NULL DEFAULT 0,
        forwardOk INTEGER NOT NULL DEFAULT 0,
        latencyMs INTEGER,
        message TEXT,
        createdAt INTEGER NOT NULL DEFAULT (unixepoch()),
        updatedAt INTEGER NOT NULL DEFAULT (unixepoch())
      );
      CREATE INDEX IF NOT EXISTS idx_forward_tests_rule ON forward_tests(ruleId, createdAt DESC);
      CREATE INDEX IF NOT EXISTS idx_forward_tests_host_status ON forward_tests(hostId, status);
    `);

    // 数据库迁移：为旧数据库添加新列（ALTER TABLE ADD COLUMN 在列已存在时会报错，忽略即可）
    try { _sqlite.exec(`ALTER TABLE hosts ADD COLUMN networkInterface TEXT`); } catch { /* column already exists */ }

    // Seed or reset default admin user
    const defaultPassword = process.env.ADMIN_PASSWORD || "admin123";
    const existing = await db.select().from(users).where(eq(users.username, "admin")).limit(1);
    if (existing.length === 0) {
      const hashedPassword = hashPassword(defaultPassword);
      await db.insert(users).values({
        username: "admin",
        password: hashedPassword,
        name: "管理员",
        email: "admin@forwardx.local",
        role: "admin",
      });
      console.log("[Database] Default admin user created (admin / admin123)");
    } else {
      // 每次启动时自动重置 admin 密码为默认值，确保旧数据库升级后也能正常登录
      const hashedPassword = hashPassword(defaultPassword);
      await db.update(users).set({ password: hashedPassword, role: "admin", updatedAt: nowDate() }).where(eq(users.username, "admin"));
      console.log("[Database] Admin password has been reset to default");
    }
    console.log("[Database] Initialization complete");
  } catch (error) {
    console.error("[Database] Initialization failed:", error);
    throw error;
  }
}

// 取出 better-sqlite3 自增 lastInsertRowid（drizzle 在 sqlite 上不返回 insertId）
function lastRowId(): number {
  if (!_sqlite) return 0;
  const r = _sqlite.prepare("SELECT last_insert_rowid() as id").get() as { id: number | bigint };
  return Number(r.id);
}

const nowDate = () => new Date();

// ==================== User Queries ====================

export async function getUserByUsername(username: string) {
  const db = await getDb();
  if (!db) return undefined;
  const r = await db.select().from(users).where(eq(users.username, username)).limit(1);
  return r[0];
}

export async function getUserById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const r = await db.select().from(users).where(eq(users.id, id)).limit(1);
  return r[0];
}

export async function authenticateUser(username: string, password: string) {
  const user = await getUserByUsername(username);
  if (!user) return null;
  if (!verifyPassword(password, user.password)) return null;
  const db = await getDb();
  if (db) {
    await db.update(users).set({ lastSignedIn: nowDate(), updatedAt: nowDate() }).where(eq(users.id, user.id));
  }
  return user;
}

export async function changeUserPassword(userId: number, oldPassword: string, newPassword: string): Promise<boolean> {
  const user = await getUserById(userId);
  if (!user) return false;
  if (!verifyPassword(oldPassword, user.password)) return false;
  const db = await getDb();
  if (!db) return false;
  await db.update(users).set({ password: hashPassword(newPassword), updatedAt: nowDate() }).where(eq(users.id, userId));
  return true;
}

export async function updateUserProfile(userId: number, data: { name?: string; email?: string }) {
  const db = await getDb();
  if (!db) return;
  await db.update(users).set({ ...data, updatedAt: nowDate() }).where(eq(users.id, userId));
}

export async function createUser(data: { username: string; password: string; name?: string; email?: string; role?: "user" | "admin" }) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.insert(users).values({
    username: data.username,
    password: hashPassword(data.password),
    name: data.name ?? data.username,
    email: data.email ?? null,
    role: data.role ?? "user",
  });
  return lastRowId();
}

export async function resetUserPassword(userId: number, newPassword: string) {
  const db = await getDb();
  if (!db) return;
  await db.update(users).set({ password: hashPassword(newPassword), updatedAt: nowDate() }).where(eq(users.id, userId));
}

export async function getAllUsers() {
  const db = await getDb();
  if (!db) return [];
  return db
    .select({
      id: users.id,
      username: users.username,
      name: users.name,
      email: users.email,
      role: users.role,
      createdAt: users.createdAt,
      lastSignedIn: users.lastSignedIn,
    })
    .from(users)
    .orderBy(desc(users.createdAt));
}

export async function updateUserRole(userId: number, role: "user" | "admin") {
  const db = await getDb();
  if (!db) return;
  await db.update(users).set({ role, updatedAt: nowDate() }).where(eq(users.id, userId));
}

export async function deleteUser(userId: number) {
  const db = await getDb();
  if (!db) return;
  await db.delete(users).where(eq(users.id, userId));
}

// ==================== Host Queries ====================

export async function getHosts(userId?: number) {
  const db = await getDb();
  if (!db) return [];
  if (userId) {
    return db.select().from(hosts).where(eq(hosts.userId, userId)).orderBy(desc(hosts.createdAt));
  }
  return db.select().from(hosts).orderBy(desc(hosts.createdAt));
}

export async function getHostById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const r = await db.select().from(hosts).where(eq(hosts.id, id)).limit(1);
  return r[0];
}

export async function createHost(host: InsertHost) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.insert(hosts).values(host);
  return lastRowId();
}

export async function updateHost(id: number, data: Partial<InsertHost>) {
  const db = await getDb();
  if (!db) return;
  await db.update(hosts).set({ ...data, updatedAt: nowDate() }).where(eq(hosts.id, id));
}

export async function deleteHost(id: number) {
  const db = await getDb();
  if (!db) return;
  await db.delete(forwardRules).where(eq(forwardRules.hostId, id));
  await db.delete(hostMetrics).where(eq(hostMetrics.hostId, id));
  await db.delete(trafficStats).where(eq(trafficStats.hostId, id));
  await db.delete(hosts).where(eq(hosts.id, id));
}

export async function updateHostHeartbeat(id: number, metrics?: Partial<InsertHost>) {
  const db = await getDb();
  if (!db) return;
  await db.update(hosts).set({ isOnline: true, lastHeartbeat: nowDate(), updatedAt: nowDate(), ...(metrics ?? {}) }).where(eq(hosts.id, id));
}

export async function getHostByAgentToken(token: string) {
  const db = await getDb();
  if (!db) return undefined;
  const r = await db.select().from(hosts).where(eq(hosts.agentToken, token)).limit(1);
  return r[0];
}

// ==================== Forward Rule Queries ====================

export async function getForwardRules(userId?: number, hostId?: number) {
  const db = await getDb();
  if (!db) return [];
  const conds: any[] = [];
  if (userId) conds.push(eq(forwardRules.userId, userId));
  if (hostId) conds.push(eq(forwardRules.hostId, hostId));
  if (conds.length > 0) {
    return db.select().from(forwardRules).where(and(...conds)).orderBy(desc(forwardRules.createdAt));
  }
  return db.select().from(forwardRules).orderBy(desc(forwardRules.createdAt));
}

export async function getForwardRuleById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const r = await db.select().from(forwardRules).where(eq(forwardRules.id, id)).limit(1);
  return r[0];
}

export async function createForwardRule(rule: InsertForwardRule) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.insert(forwardRules).values(rule);
  return lastRowId();
}

export async function updateForwardRule(id: number, data: Partial<InsertForwardRule>) {
  const db = await getDb();
  if (!db) return;
  await db.update(forwardRules).set({ ...data, updatedAt: nowDate() }).where(eq(forwardRules.id, id));
}

export async function deleteForwardRule(id: number) {
  const db = await getDb();
  if (!db) return;
  await db.delete(trafficStats).where(eq(trafficStats.ruleId, id));
  await db.delete(forwardRules).where(eq(forwardRules.id, id));
}

export async function toggleForwardRule(id: number, isEnabled: boolean) {
  const db = await getDb();
  if (!db) return;
  await db.update(forwardRules).set({ isEnabled, updatedAt: nowDate() }).where(eq(forwardRules.id, id));
}

export async function updateRuleRunningStatus(id: number, isRunning: boolean) {
  const db = await getDb();
  if (!db) return;
  await db.update(forwardRules).set({ isRunning, updatedAt: nowDate() }).where(eq(forwardRules.id, id));
}

// ==================== Host Metrics Queries ====================

export async function insertHostMetric(metric: InsertHostMetric) {
  const db = await getDb();
  if (!db) return;
  await db.insert(hostMetrics).values(metric);
}

export async function getLatestHostMetrics(hostId: number, limit = 60) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(hostMetrics).where(eq(hostMetrics.hostId, hostId)).orderBy(desc(hostMetrics.recordedAt)).limit(limit);
}

// ==================== Traffic Stats Queries ====================

export async function insertTrafficStat(stat: InsertTrafficStat) {
  const db = await getDb();
  if (!db) return;
  await db.insert(trafficStats).values(stat);
}

export async function getTrafficStats(ruleId: number, limit = 60) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(trafficStats).where(eq(trafficStats.ruleId, ruleId)).orderBy(desc(trafficStats.recordedAt)).limit(limit);
}

export async function getTotalTraffic() {
  const db = await getDb();
  if (!db) return { totalIn: 0, totalOut: 0 };
  const r = await db.select({
    totalIn: sql<number>`COALESCE(SUM(bytesIn), 0)`,
    totalOut: sql<number>`COALESCE(SUM(bytesOut), 0)`,
  }).from(trafficStats);
  const row = r[0];
  return {
    totalIn: Number(row?.totalIn) || 0,
    totalOut: Number(row?.totalOut) || 0,
  };
}

/** 按规则汇总流量（可限定 userId / hostId / 起始时间） */
export async function getTrafficSummaryByRule(opts: {
  userId?: number;
  hostId?: number;
  since?: Date;
} = {}) {
  const db = await getDb();
  if (!db) return [] as Array<{ ruleId: number; hostId: number; bytesIn: number; bytesOut: number; connections: number }>;
  const conds: any[] = [];
  if (opts.hostId) conds.push(eq(trafficStats.hostId, opts.hostId));
  if (opts.since) conds.push(gte(trafficStats.recordedAt, opts.since));
  const baseQuery = db
    .select({
      ruleId: trafficStats.ruleId,
      hostId: trafficStats.hostId,
      bytesIn: sql<number>`COALESCE(SUM(${trafficStats.bytesIn}), 0)`,
      bytesOut: sql<number>`COALESCE(SUM(${trafficStats.bytesOut}), 0)`,
      connections: sql<number>`COALESCE(SUM(${trafficStats.connections}), 0)`,
    })
    .from(trafficStats);
  const rows = await (conds.length ? baseQuery.where(and(...conds)) : baseQuery).groupBy(trafficStats.ruleId, trafficStats.hostId);

  let result = rows.map((r) => ({
    ruleId: Number(r.ruleId),
    hostId: Number(r.hostId),
    bytesIn: Number(r.bytesIn) || 0,
    bytesOut: Number(r.bytesOut) || 0,
    connections: Number(r.connections) || 0,
  }));

  if (opts.userId) {
    const allowed = await db.select({ id: hosts.id }).from(hosts).where(eq(hosts.userId, opts.userId));
    const ok = new Set(allowed.map((h) => Number(h.id)));
    result = result.filter((r) => ok.has(r.hostId));
  }
  return result;
}

/** 按时间分桶聚合某条规则的流量序列（默认 1 分钟一个点） */
export async function getTrafficSeriesByRule(
  ruleId: number,
  opts: { bucketMinutes?: number; since?: Date } = {}
) {
  const db = await getDb();
  if (!db) return [] as Array<{ bucket: Date; bytesIn: number; bytesOut: number; connections: number }>;
  const bucket = Math.max(1, opts.bucketMinutes ?? 1);
  const since = opts.since ?? new Date(Date.now() - 60 * 60 * 1000);
  const sinceSec = Math.floor(since.getTime() / 1000);
  const bucketSec = bucket * 60;

  // SQLite 中 recordedAt 已经是 unix 秒（integer）
  const rows = await db
    .select({
      bucket: sql<number>`(${trafficStats.recordedAt} / ${bucketSec}) * ${bucketSec}`,
      bytesIn: sql<number>`COALESCE(SUM(${trafficStats.bytesIn}), 0)`,
      bytesOut: sql<number>`COALESCE(SUM(${trafficStats.bytesOut}), 0)`,
      connections: sql<number>`COALESCE(SUM(${trafficStats.connections}), 0)`,
    })
    .from(trafficStats)
    .where(and(eq(trafficStats.ruleId, ruleId), gte(trafficStats.recordedAt, since)))
    .groupBy(sql`bucket`)
    .orderBy(asc(sql`bucket`));

  return rows.map((r) => ({
    bucket: new Date(Number(r.bucket) * 1000),
    bytesIn: Number(r.bytesIn) || 0,
    bytesOut: Number(r.bytesOut) || 0,
    connections: Number(r.connections) || 0,
  })).filter((r) => r.bucket.getTime() / 1000 >= sinceSec);
}

// ==================== Agent Token Queries ====================

export async function createAgentToken(data: InsertAgentToken) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.insert(agentTokens).values(data);
  return lastRowId();
}

export async function getAgentTokenByToken(token: string) {
  const db = await getDb();
  if (!db) return undefined;
  const r = await db.select().from(agentTokens).where(eq(agentTokens.token, token)).limit(1);
  return r[0];
}

export async function getAgentTokens(userId?: number) {
  const db = await getDb();
  if (!db) return [];
  if (userId) {
    return db.select().from(agentTokens).where(eq(agentTokens.userId, userId)).orderBy(desc(agentTokens.createdAt));
  }
  return db.select().from(agentTokens).orderBy(desc(agentTokens.createdAt));
}

export async function markAgentTokenUsed(token: string, hostId: number) {
  const db = await getDb();
  if (!db) return;
  await db.update(agentTokens).set({ isUsed: true, hostId }).where(eq(agentTokens.token, token));
}

export async function deleteAgentToken(id: number) {
  const db = await getDb();
  if (!db) return;
  await db.delete(agentTokens).where(eq(agentTokens.id, id));
}

// ==================== Dashboard Stats ====================

export async function getDashboardStats(userId?: number) {
  const db = await getDb();
  if (!db) return { totalHosts: 0, onlineHosts: 0, totalRules: 0, activeRules: 0, totalTrafficIn: 0, totalTrafficOut: 0 };

  const hostConditions = userId ? eq(hosts.userId, userId) : undefined;
  const ruleConditions = userId ? eq(forwardRules.userId, userId) : undefined;

  const hostStatsRows = await db
    .select({
      totalHosts: sql<number>`COUNT(*)`,
      onlineHosts: sql<number>`SUM(CASE WHEN isOnline = 1 THEN 1 ELSE 0 END)`,
    })
    .from(hosts)
    .where(hostConditions as any);

  const ruleStatsRows = await db
    .select({
      totalRules: sql<number>`COUNT(*)`,
      activeRules: sql<number>`SUM(CASE WHEN isEnabled = 1 AND isRunning = 1 THEN 1 ELSE 0 END)`,
    })
    .from(forwardRules)
    .where(ruleConditions as any);

  const hostStats = hostStatsRows[0];
  const ruleStats = ruleStatsRows[0];
  const traffic = await getTotalTraffic();

  return {
    totalHosts: Number(hostStats?.totalHosts) || 0,
    onlineHosts: Number(hostStats?.onlineHosts) || 0,
    totalRules: Number(ruleStats?.totalRules) || 0,
    activeRules: Number(ruleStats?.activeRules) || 0,
    totalTrafficIn: traffic.totalIn,
    totalTrafficOut: traffic.totalOut,
  };
}

// ==================== Forward Tests ====================

export async function createForwardTest(data: InsertForwardTest) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db.insert(forwardTests).values(data);
  return lastRowId();
}

export async function getPendingForwardTestsByHost(hostId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(forwardTests)
    .where(and(eq(forwardTests.hostId, hostId), eq(forwardTests.status, "pending")));
}

export async function markForwardTestRunning(id: number) {
  const db = await getDb();
  if (!db) return;
  await db.update(forwardTests).set({ status: "running", updatedAt: nowDate() }).where(eq(forwardTests.id, id));
}

export async function updateForwardTestResult(
  id: number,
  data: {
    status: "success" | "failed" | "timeout";
    listenOk?: boolean;
    targetReachable?: boolean;
    forwardOk?: boolean;
    latencyMs?: number | null;
    message?: string | null;
  }
) {
  const db = await getDb();
  if (!db) return;
  await db.update(forwardTests).set({ ...data, updatedAt: nowDate() } as any).where(eq(forwardTests.id, id));
}

export async function getLatestForwardTest(ruleId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const rows = await db
    .select()
    .from(forwardTests)
    .where(eq(forwardTests.ruleId, ruleId))
    .orderBy(desc(forwardTests.createdAt))
    .limit(1);
  return rows[0];
}

export async function getForwardTestById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const rows = await db.select().from(forwardTests).where(eq(forwardTests.id, id)).limit(1);
  return rows[0];
}
